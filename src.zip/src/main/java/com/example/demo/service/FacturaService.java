package com.example.demo.service;

import com.itextpdf.text.DocumentException;
import java.io.IOException;
import jakarta.mail.MessagingException;

/**
 * Servicio para generación y envío de facturas en PDF.
 */
public interface FacturaService {
    /**
     * Genera el PDF de la factura del pedido indicado.
     * @param pedidoId ID del pedido
     * @return contenido del PDF como arreglo de bytes
     */
    byte[] generarFacturaPdf(Long pedidoId) throws DocumentException, IOException;

    /**
     * Envía el PDF de la factura al correo del cliente asociado al pedido.
     * @param pedidoId ID del pedido
     */
    void enviarFacturaPorCorreo(Long pedidoId);  // <- ya no lanza excepciones checked
}
