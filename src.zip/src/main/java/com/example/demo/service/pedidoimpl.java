package com.example.demo.service;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;

import com.example.demo.dao.UsuarioRepository;
import com.example.demo.dao.pedido_platorepository;
import com.example.demo.dao.pedidorepository;
import com.example.demo.dao.platorepository;
import com.example.demo.entity.Pedido;
import com.example.demo.entity.PedidoPlato;
import com.example.demo.entity.Plato;
import com.example.demo.entity.Usuario;
import com.stripe.Stripe;
import com.stripe.exception.StripeException;
import com.stripe.model.Refund;
import com.stripe.param.RefundCreateParams;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

@Service
public class pedidoimpl implements pedidoservice {
    private static final Logger log = LoggerFactory.getLogger(pedidoimpl.class);

    @Autowired
    private pedidorepository pedidorepo;

    @Autowired
    private UsuarioRepository usuariorepo;

    @Autowired
    private platorepository platorepo;

    @Autowired
    private pedido_platorepository pedido_platodao;

    @SuppressWarnings("unchecked")
    @Override
    public ResponseEntity<String> guardarPedido(Map<String, Object> params, LocalDateTime datetime) {
        try {
            String correo = (String) params.get("correo");
            Usuario usuario = usuariorepo.findByCorreo(correo);
            if (usuario == null) {
                return ResponseEntity.badRequest().body("Usuario no encontrado");
            }

            List<Integer> idPlatos = (List<Integer>) params.get("id_platos");
            List<Integer> cantidades = (List<Integer>) params.get("cantidades");
            List<Plato> platos = platorepo.findAllById(idPlatos);
            if (platos.isEmpty()) {
                return ResponseEntity.badRequest().body("Platos no encontrados");
            }

            Pedido pedido = new Pedido();
            pedido.setId_usuario(usuario);
            pedido.setFecha(datetime);
            pedido.setEstado((String) params.get("estado"));

            List<PedidoPlato> pedidoPlatos = new ArrayList<>();
            for (int i = 0; i < platos.size(); i++) {
                Plato plato = platos.get(i);
                int cantidad = cantidades.get(i);

                PedidoPlato pedidoPlato = new PedidoPlato();
                pedidoPlato.setPedido(pedido);
                pedidoPlato.setPlato(plato);
                pedidoPlato.setCantidad(cantidad);
                pedidoPlatos.add(pedidoPlato);
            }
            pedido.setPedidoPlatos(pedidoPlatos);
            pedido.calcularTotal();
            pedidorepo.save(pedido);
            return ResponseEntity.ok("Pedido guardado correctamente");
        } catch (Exception e) {
            log.error("Error al guardar pedido", e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body("Error al guardar el pedido: " + e.getMessage());
        }
    }
@Override
public List<Pedido> listarPedidosPendientes() {
    return pedidorepo.findByEstado("ESPERA");
}

@Override
public List<Pedido> listarPedidosAtendidos() {
    return pedidorepo.findByEstadoIn(Arrays.asList("atendido", "terminado"));
}
    @Override
    public List<Pedido> traerPedidobycorreo(String correo) {
        List<Pedido> pedidos = pedidorepo.findPedidobyCorreo(correo);
        if (pedidos == null) {
            return new ArrayList<>();
        }
        for (Pedido pedido : pedidos) {
            pedido.calcularTotal();
            pedidorepo.save(pedido);
        }
        return pedidos;
    }

    @SuppressWarnings("unchecked")
    @Override
    public ResponseEntity<String> agregarplatos(Map<String, Object> params) {
        Pedido pedido = pedidorepo.findById((int) params.get("id")).orElse(null);
        if (Objects.isNull(pedido)) {
            return ResponseEntity.badRequest().body("Pedido no encontrado");
        }
        List<Integer> idplatos = (List<Integer>) params.get("id_platos");
        List<Integer> cantidades = (List<Integer>) params.get("cantidades");
        if (Objects.isNull(idplatos) || idplatos.isEmpty() || Objects.isNull(cantidades) || cantidades.isEmpty()
                || idplatos.size() != cantidades.size()) {
            return ResponseEntity.badRequest().body("Datos de platos inválidos");
        }

        List<Plato> platos = platorepo.findAllById(idplatos);
        for (int i = 0; i < platos.size(); i++) {
            Plato plato = platos.get(i);
            int cantidad = cantidades.get(i);
            PedidoPlato pedidoPlato = new PedidoPlato();
            pedidoPlato.setPedido(pedido);
            pedidoPlato.setPlato(plato);
            pedidoPlato.setCantidad(cantidad);
            pedido_platodao.save(pedidoPlato);
        }

        pedido.calcularTotal();
        pedidorepo.save(pedido);
        return ResponseEntity.ok("Platos agregados al pedido correctamente");
    }

    @Override
    public ResponseEntity<String> eliminarplatopedido(int id_plato, int id_pedidoplato) {
        Plato plato = platorepo.findById(id_plato);
        if (plato == null) {
            return ResponseEntity.badRequest().body("Plato no encontrado");
        }
        PedidoPlato pedidoplato = pedido_platodao.encontrarpedidoplatoporplatoyid(plato.getId_plato(), id_pedidoplato);
        if (pedidoplato == null) {
            return ResponseEntity.badRequest().body("Pedido-Plato no encontrado");
        }
        pedido_platodao.delete(pedidoplato);

        Pedido pedido = pedidoplato.getPedido();
        pedido.calcularTotal();
        pedidorepo.save(pedido);

        List<PedidoPlato> restantes = pedido_platodao.findByPedidoId(pedido.getId_pedido());
        if (restantes.isEmpty()) {
            pedidorepo.delete(pedido);
            return ResponseEntity.ok("Plato eliminado. El pedido fue eliminado porque no tiene más platos.");
        }
        return ResponseEntity.ok("Plato eliminado del pedido correctamente");
    }

    @Override
    public ResponseEntity<String> actualizarEstado(Map<String, String> request) {
        String idString = request.get("id_pedido");
        int id = Integer.parseInt(idString);
        Pedido pedido = pedidorepo.findById(id).orElse(null);
        if (pedido == null) {
            return ResponseEntity.badRequest().body("Pedido no encontrado");
        }
        pedido.setEstado("atendido");
        pedidorepo.save(pedido);
        return ResponseEntity.ok("Pedido actualizado correctamente");
    }

    @Override
    public ResponseEntity<String> rembolso(Map<String, String> requestMap, String secretKey) {
        // 1) Validar id_pedido
        String idString = requestMap.get("id_pedido");
        if (idString == null) {
            return ResponseEntity.badRequest().body("Falta id_pedido en la solicitud");
        }
        int pedidoId;
        try {
            pedidoId = Integer.parseInt(idString);
        } catch (NumberFormatException e) {
            return ResponseEntity.badRequest().body("id_pedido inválido: " + idString);
        }
        // 2) Cargar pedido
        Pedido pedido = pedidorepo.findById(pedidoId).orElse(null);
        if (pedido == null) {
            return ResponseEntity.badRequest().body("Pedido no encontrado: " + pedidoId);
        }
        // 3) Verificar payment intent
        String paymentIntentId = pedido.getId_pago();
        if (paymentIntentId == null || paymentIntentId.isEmpty()) {
            return ResponseEntity.badRequest().body("El pedido no tiene un pago registrado");
        }
        try {
            // 4) Configurar Stripe y crear reembolso
            Stripe.apiKey = secretKey;
            RefundCreateParams params = RefundCreateParams.builder()
                    .setPaymentIntent(paymentIntentId)
                    .build();
            Refund refund = Refund.create(params);
            // 5) Chequear estado y guardar
            if ("succeeded".equals(refund.getStatus())) {
                pedido.setEstado("REEMBOLSADO");
                pedidorepo.save(pedido);
                return ResponseEntity.ok("Reembolso realizado correctamente. ID: " + refund.getId());
            }
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body("Reembolso con status inesperado: " + refund.getStatus());
        } catch (StripeException e) {
            log.error("Error de Stripe al reembolso: {}", e.getMessage(), e);
            return ResponseEntity.status(HttpStatus.BAD_GATEWAY)
                    .body("Error de Stripe: " + e.getMessage());
        } catch (Exception e) {
            log.error("Error interno al procesar reembolso", e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body("Error interno al procesar reembolso: " + e.getMessage());
        }
    }
}
