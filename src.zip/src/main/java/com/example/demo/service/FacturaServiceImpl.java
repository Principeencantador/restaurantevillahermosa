package com.example.demo.service;

import com.example.demo.dao.pedidorepository;
import com.example.demo.entity.Pedido;
import com.example.demo.entity.PedidoPlato;
import com.itextpdf.text.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.itextpdf.text.pdf.*;

import com.google.zxing.BarcodeFormat;
import com.google.zxing.WriterException;
import com.google.zxing.qrcode.QRCodeWriter;
import com.google.zxing.common.BitMatrix;

import jakarta.mail.MessagingException;
import jakarta.mail.internet.MimeMessage;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.stereotype.Service;

import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.math.BigDecimal;
import java.math.RoundingMode;

@Service
public class FacturaServiceImpl implements FacturaService {

      private static final Logger log = LoggerFactory.getLogger(FacturaServiceImpl.class);
      
    @Autowired
    private pedidorepository pedidoRepo;

    @Autowired
    private JavaMailSender mailSender;

    @Override
    public byte[] generarFacturaPdf(Long pedidoId) throws DocumentException, IOException {
        Pedido pedido = pedidoRepo.findById(Math.toIntExact(pedidoId))
                .orElseThrow(() -> new RuntimeException("Pedido no encontrado: " + pedidoId));

        Document doc = new Document(new Rectangle(226, 850));
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        PdfWriter writer = PdfWriter.getInstance(doc, baos);
        doc.open();

        Font courierBold = new Font(Font.FontFamily.COURIER, 10, Font.BOLD);
        Font courier = new Font(Font.FontFamily.COURIER, 9);
        Font courierSmall = new Font(Font.FontFamily.COURIER, 8);

        Paragraph empresa = new Paragraph("VILLAHERMOSA SAC\nRUC: 12345678901", courierBold);
        empresa.setAlignment(Element.ALIGN_CENTER);
        doc.add(empresa);

        doc.add(new Paragraph("Restaurante de Comida Criolla", courierSmall));
        doc.add(new Paragraph("AV. LAS FLORES 123 - ICA - PERÚ", courierSmall));
        doc.add(Chunk.NEWLINE);

        doc.add(new Paragraph("BOLETA DE VENTA ELECTRÓNICA", courierBold));
        doc.add(new Paragraph("Serie: BE01  N° " + String.format("%06d", pedido.getId_pedido()), courier));
        doc.add(new Paragraph("--------------------------------------------------", courierSmall));

        String dniFicticio = String.format("%08d", (int) (Math.random() * 100000000));
        doc.add(new Paragraph("DNI: " + dniFicticio, courier));
        doc.add(new Paragraph("Cliente: " + pedido.getId_usuario().getNombre(), courier));
        doc.add(new Paragraph("Email: " + pedido.getId_usuario().getEmail(), courier));
        doc.add(new Paragraph("--------------------------------------------------", courierSmall));

        doc.add(new Paragraph("Fecha emisión : " + pedido.getFecha(), courier));
        doc.add(new Paragraph("Moneda        : SOLES", courier));
        doc.add(new Paragraph("--------------------------------------------------", courierSmall));
        doc.add(new Paragraph("Cant.  Descripción             Importe", courierBold));
        doc.add(new Paragraph("--------------------------------------------------", courierSmall));

        for (PedidoPlato pp : pedido.getPedidoPlatos()) {
            String linea = String.format("%-5s %-20s S/. %.2f",
                    pp.getCantidad(),
                    cortarTexto(pp.getPlato().getNombre(), 20),
                    pp.getPlato().getPrecio() * pp.getCantidad());
            doc.add(new Paragraph(linea, courier));
        }

        doc.add(new Paragraph("--------------------------------------------------", courierSmall));

        BigDecimal total = BigDecimal.valueOf(pedido.getTotal());
        BigDecimal subtotal = total.divide(BigDecimal.valueOf(1.18), 2, RoundingMode.HALF_UP);
        BigDecimal igv = total.subtract(subtotal);

        doc.add(new Paragraph(String.format("Gravada:      S/. %.2f", subtotal), courier));
        doc.add(new Paragraph(String.format("IGV (18%%):    S/. %.2f", igv), courier));
        doc.add(new Paragraph(String.format("Total:        S/. %.2f", total), courierBold));

        doc.add(new Paragraph("--------------------------------------------------", courierSmall));
        doc.add(new Paragraph("SON: " + convertirTotal(total).toUpperCase() + " SOLES", courier));
        doc.add(new Paragraph("Forma de pago: IZIPAY - VISA", courier));
        doc.add(new Paragraph("Transacción: Venta Electrónica", courier));
        doc.add(new Paragraph("--------------------------------------------------", courierSmall));

        doc.add(new Paragraph("Gracias por su preferencia.", courierSmall));
        doc.add(new Paragraph("Autorizado mediante R.S. N° 123-456-2022/SUNAT", courierSmall));
        doc.add(new Paragraph("www.villahermosa.pe/consulta-cpe", courierSmall));
        doc.add(Chunk.NEWLINE);

        // Generar código QR
        try {
            String qrData = "https://villahermosa.pe/consulta-cpe?id=" + pedido.getId_pedido();
            Image qrImage = generarQR(qrData, 100, 100);
            qrImage.setAlignment(Image.ALIGN_CENTER);
            doc.add(qrImage);
        } catch (Exception e) {
            doc.add(new Paragraph("QR no disponible", courierSmall));
        }

        doc.close();
        return baos.toByteArray();
    }

    private Image generarQR(String data, int width, int height)
            throws WriterException, IOException, BadElementException {
        QRCodeWriter qrCodeWriter = new QRCodeWriter();
        BitMatrix matrix = qrCodeWriter.encode(data, BarcodeFormat.QR_CODE, width, height);

        BufferedImage bufferedImage = new BufferedImage(width, height, BufferedImage.TYPE_INT_RGB);
        for (int x = 0; x < width; x++) {
            for (int y = 0; y < height; y++) {
                bufferedImage.setRGB(x, y,
                        matrix.get(x, y) ? java.awt.Color.BLACK.getRGB() : java.awt.Color.WHITE.getRGB());
            }
        }

        ByteArrayOutputStream pngOutputStream = new ByteArrayOutputStream();
        ImageIO.write(bufferedImage, "png", pngOutputStream);
        return Image.getInstance(pngOutputStream.toByteArray());
    }

    private String cortarTexto(String texto, int maxLen) {
        return texto.length() > maxLen ? texto.substring(0, maxLen - 3) + "..." : texto;
    }

    private String convertirTotal(BigDecimal total) {
        int soles = total.intValue();
        int centavos = total.remainder(BigDecimal.ONE).multiply(BigDecimal.valueOf(100)).intValue();
        return String.format("%s con %02d/100", numeroATexto(soles), centavos);
    }

    private String numeroATexto(int num) {
        String[] unidades = {
                "Cero", "Uno", "Dos", "Tres", "Cuatro", "Cinco", "Seis",
                "Siete", "Ocho", "Nueve", "Diez", "Once", "Doce", "Trece",
                "Catorce", "Quince", "Dieciséis", "Diecisiete", "Dieciocho", "Diecinueve", "Veinte"
        };
        if (num <= 20)
            return unidades[num];
        if (num < 30)
            return "Veinti" + unidades[num - 20].toLowerCase();
        return String.valueOf(num);
    }

  @Override
    public void enviarFacturaPorCorreo(Long pedidoId) {
        try {
            // 1) Generar el PDF
            byte[] pdf = generarFacturaPdf(pedidoId);

            // 2) Recuperar datos del pedido
            Pedido pedido = pedidoRepo.findById(Math.toIntExact(pedidoId))
                    .orElseThrow(() -> new RuntimeException("Pedido no encontrado: " + pedidoId));

            // 3) Construir mensaje
            MimeMessage message = mailSender.createMimeMessage();
            MimeMessageHelper helper = new MimeMessageHelper(message, true, "UTF-8");
            helper.setTo(pedido.getId_usuario().getEmail());
            helper.setSubject("Factura Pedido #" + pedido.getId_pedido());
            helper.setText(
                "Hola " + pedido.getId_usuario().getNombre() + ",\n\n"
              + "Adjunto tu boleta de compra. ¡Gracias por confiar en nosotros!\n\n"
              + "Saludos,\nEquipo Villahermosa",
                false
            );
            helper.addAttachment(
                "factura_" + pedido.getId_pedido() + ".pdf",
                new ByteArrayResource(pdf)
            );

            // 4) Enviar
            mailSender.send(message);

        } catch (DocumentException | IOException | MessagingException e) {
            // Aquí capturamos TODO: generación de PDF y envío de mail
            log.error("No se pudo enviar la boleta para pedido {}: {}", pedidoId, e.getMessage(), e);
        }
    }
        }