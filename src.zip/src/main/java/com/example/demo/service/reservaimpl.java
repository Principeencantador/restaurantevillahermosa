package com.example.demo.service;

import com.example.demo.dao.UsuarioRepository;
import com.example.demo.dao.mesarepository;
import com.example.demo.dao.reservarepository;
import com.example.demo.entity.Mesa;
import com.example.demo.entity.Reserva;
import com.example.demo.entity.Usuario;

import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.http.HttpStatus;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import jakarta.servlet.http.HttpServletResponse;

import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.stream.Stream;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.Month;
import java.time.ZoneId;
import java.time.format.TextStyle;
import java.io.ByteArrayOutputStream;
import java.io.IOException;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.FillPatternType;
import org.apache.poi.ss.usermodel.IndexedColors;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.util.CellRangeAddress;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.apache.poi.xssf.usermodel.XSSFFont;

import com.itextpdf.text.BaseColor;
import com.itextpdf.text.Chunk;
import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.Element;
import com.itextpdf.text.Font;
import com.itextpdf.text.Image;
import com.itextpdf.text.PageSize;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.Phrase;
import com.itextpdf.text.pdf.PdfPCell;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.PdfWriter;

import org.jfree.chart.ChartFactory;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.plot.PiePlot;
import org.jfree.data.general.DefaultPieDataset;

import javax.imageio.ImageIO;
import java.awt.Color;
import java.awt.image.BufferedImage;

@Service
public class reservaimpl implements reservaservice {

    private final reservarepository reservaRepo;
    private final mesarepository    mesaRepo;
    private final UsuarioRepository usuarioRepo;

    @Autowired
    public reservaimpl(
        reservarepository reservaRepo,
        mesarepository    mesaRepo,
        UsuarioRepository usuarioRepo
    ) {
        this.reservaRepo = reservaRepo;
        this.mesaRepo    = mesaRepo;
        this.usuarioRepo = usuarioRepo;
    }

    @Override
    public ResponseEntity<String> crear(
        LocalDateTime fechaHoraInicio,
        LocalDateTime fechaHoraFin,
        int nro_mesa,
        String nombre,
        String apellido,
        String correo,
        String telefono,
        int id_usuario,
        int cantidad
    ) {
        Mesa mesa = mesaRepo.mesanro(nro_mesa);
        Usuario usuario = usuarioRepo.findById(id_usuario).orElse(null);

        if (mesa == null) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND)
                                 .body("Mesa no encontrada");
        }
        if (usuario == null) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND)
                                 .body("Usuario no encontrado");
        }

        int ocupados = reservaRepo.contarPersonasEnRango(fechaHoraInicio, fechaHoraFin);
        if (ocupados + cantidad > 35) {
            return ResponseEntity.badRequest()
                                 .body("No hay disponibilidad en ese rango");
        }

        List<Reserva> misReservas = reservaRepo.findReservabyusuario(id_usuario);
        long reservasPendientes = misReservas.stream()
                                             .filter(r -> r.getEstado().equals("pendiente"))
                                             .count();
        if (reservasPendientes >= 5) {
            return ResponseEntity.badRequest()
                                 .body("Ya tienes 5 reservas pendientes. No puedes hacer más reservas.");
        }

        if (fechaHoraInicio.isBefore(LocalDateTime.now(ZoneId.of("America/Lima")))) {
            return ResponseEntity.badRequest()
                                 .body("La fecha ya pasó");
        }

        boolean solapa = misReservas.stream().anyMatch(r ->
            r.getMesa().getNroMesa() == nro_mesa &&
            !r.getFechaHora().isAfter(fechaHoraFin) &&
            !fechaHoraInicio.isAfter(r.getFechaHoraFin())
        );
        if (solapa) {
            return ResponseEntity.status(HttpStatus.CONFLICT)
                                 .body("Ya existe reserva en rango para esta mesa");
        }

        Reserva nueva = new Reserva();
        nueva.setUsuario(usuario);
        nueva.setNombre(nombre);
        nueva.setApellido(apellido);
        nueva.setCorreo(correo);
        nueva.setTelefono(telefono);
        nueva.setMesa(mesa);
        nueva.setFechaHora(fechaHoraInicio);
        nueva.setFechaHoraFin(fechaHoraFin);
        nueva.setCantidad(cantidad);
        nueva.setEstado("pendiente");
        reservaRepo.save(nueva);

        return ResponseEntity.ok("Reserva creada correctamente");
    }

    @Override
    public List<Reserva> traerreserva(LocalDate fecha) {
        return reservaRepo.findbyestado(fecha);
    }

    @Override
    public List<Reserva> atendido() {
        return reservaRepo.atendidos();
    }

    @Override
    public void actualizarEstadoReserva() {
        LocalDateTime ahora = LocalDateTime.now();
        List<Reserva> reservas = reservaRepo.findByEstadoInAndFechaHoraFinBefore(
            List.of("pendiente", "confirmado"), ahora
        );
        for (Reserva reserva : reservas) {
            if (!reserva.getEstado().equals("cancelado")) {
                reserva.setEstado("exitoso");
                reservaRepo.save(reserva);
            }
        }
    }

    @Scheduled(fixedRate = 60000)
    public void ejecutarActualizacionEstadoReserva() {
        actualizarEstadoReserva();
    }

    @Override
    public ResponseEntity<String> eliminar(int idreserva) {
        Reserva r = reservaRepo.findById(idreserva).orElse(null);
        if (r == null) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND)
                                 .body("Reserva no encontrada");
        }
        reservaRepo.delete(r);
        return ResponseEntity.ok("Reserva eliminada");
    }

    @Override
    public ResponseEntity<String> actualizarEstado(Map<String,Integer> req) {
        Integer id = req.get("idReserva");
        Reserva r = reservaRepo.findById(id).orElse(null);
        if (r == null) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND)
                                 .body("Reserva no encontrada");
        }
        r.setEstado("atendido");
        reservaRepo.save(r);
        return ResponseEntity.ok("Estado cambiado a atendido");
    }

    // ================= PDF con iText 5 =================
@Override
public ByteArrayOutputStream crearReportePdf(HttpServletResponse response)
    throws DocumentException, IOException {

    List<Reserva> todas = reservaRepo.findAll();

    Document document = new Document(PageSize.A4, 36, 36, 64, 36);
    ByteArrayOutputStream baos = new ByteArrayOutputStream();
    PdfWriter.getInstance(document, baos);
    document.open();

    Font titleFont  = new Font(Font.FontFamily.HELVETICA, 16, Font.BOLD);
    Font headerFont = new Font(Font.FontFamily.HELVETICA, 12, Font.BOLD);
    Font cellFont   = new Font(Font.FontFamily.HELVETICA, 10);
    Font small      = new Font(Font.FontFamily.HELVETICA, 9);

    Paragraph title = new Paragraph("REPORTE DE RESERVAS (TODAS)", titleFont);
    title.setAlignment(Element.ALIGN_CENTER);
    document.add(title);
    document.add(Chunk.NEWLINE);

    Authentication auth = SecurityContextHolder.getContext().getAuthentication();
    String username = auth != null ? auth.getName() : "desconocido";
    String timestamp = LocalDateTime.now().format(DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm"));
    Paragraph meta = new Paragraph(String.format("Fecha: %s    Usuario: %s", timestamp, username), small);
    meta.setAlignment(Element.ALIGN_RIGHT);
    document.add(meta);
    document.add(Chunk.NEWLINE);

    PdfPTable table = new PdfPTable(8);
    table.setWidthPercentage(100);
    table.setWidths(new float[]{1.2f,3f,3f,2.5f,1.5f,1.5f,2f,4f});
    Stream.of("N°","Cliente","Correo","Teléfono","Mesa","Personas","Estado","Comentarios")
          .forEach(h -> {
              PdfPCell c = new PdfPCell(new Phrase(h, headerFont));
              c.setHorizontalAlignment(Element.ALIGN_CENTER);
              c.setBackgroundColor(BaseColor.LIGHT_GRAY);
              c.setPadding(5);
              table.addCell(c);
          });
    int cnt = 1;
    for (Reserva r : todas) {
        table.addCell(new PdfPCell(new Phrase(String.valueOf(cnt++), cellFont)));
        table.addCell(new PdfPCell(new Phrase(r.getNombre()+" "+r.getApellido(), cellFont)));
        table.addCell(new PdfPCell(new Phrase(r.getCorreo(), cellFont)));
        table.addCell(new PdfPCell(new Phrase(r.getTelefono(), cellFont)));
        table.addCell(new PdfPCell(new Phrase(String.valueOf(r.getMesa().getNroMesa()), cellFont)));
        table.addCell(new PdfPCell(new Phrase(String.valueOf(r.getCantidad()), cellFont)));
        table.addCell(new PdfPCell(new Phrase(r.getEstado(), cellFont)));
        String motivo = r.getMotivoCancelacion() != null
                       ? r.getMotivoCancelacion()
                       : r.getComentario() != null
                         ? r.getComentario()
                         : "";
        table.addCell(new PdfPCell(new Phrase(motivo, cellFont)));
    }
    document.add(table);


    

    // Semestre Ene–Jun
    long totalSem1  = todas.stream().filter(r -> r.getFechaHora().getMonthValue() <= 6).count();
    long cancelSem1 = todas.stream()
                           .filter(r -> r.getFechaHora().getMonthValue() <= 6)
                           .filter(r -> "cancelado".equalsIgnoreCase(r.getEstado()))
                           .count();
    long exitosSem1 = todas.stream()
                           .filter(r -> r.getFechaHora().getMonthValue() <= 6)
                           .filter(r -> "exitoso".equalsIgnoreCase(r.getEstado()))
                           .count();
    long pendSem1   = todas.stream()
                           .filter(r -> r.getFechaHora().getMonthValue() <= 6)
                           .filter(r -> "pendiente".equalsIgnoreCase(r.getEstado()))
                           .count();

    DefaultPieDataset ds1 = new DefaultPieDataset();
    ds1.setValue("Exitosos",   exitosSem1);
    ds1.setValue("Cancelados", cancelSem1);
    ds1.setValue("Pendientes", pendSem1);

    JFreeChart chart1 = ChartFactory.createPieChart("Resumen Semestral (Ene–Jun)", ds1, true, false, false);
    PiePlot plot1 = (PiePlot) chart1.getPlot();
    plot1.setSectionPaint("Exitosos", new Color(34,139,34));
    plot1.setSectionPaint("Cancelados", Color.RED);
    plot1.setSectionPaint("Pendientes", Color.GRAY);
    plot1.setBackgroundPaint(null);
    plot1.setOutlineVisible(false);

    BufferedImage img1 = chart1.createBufferedImage(400, 300);
    ByteArrayOutputStream baos1 = new ByteArrayOutputStream();
    ImageIO.write(img1, "png", baos1);
    Image itext1 = Image.getInstance(baos1.toByteArray());
    itext1.setAlignment(Element.ALIGN_CENTER);
    itext1.scaleToFit(400, 300);


    document.add(Chunk.NEWLINE);
    Paragraph pct1 = new Paragraph(
      String.format(
        "Exitosos: %d (%.1f%%)   Cancelados: %d (%.1f%%)   Pendientes: %d (%.1f%%)",
        exitosSem1, totalSem1>0 ? exitosSem1*100.0/totalSem1 : 0,
        cancelSem1, totalSem1>0 ? cancelSem1*100.0/totalSem1 : 0,
        pendSem1,   totalSem1>0 ? pendSem1*100.0/totalSem1 : 0
      ),
      small
    );
    pct1.setAlignment(Element.ALIGN_CENTER);
    document.add(pct1);
    document.add(Chunk.NEWLINE);

    document.add(itext1);
    // Semestre Jul–Dic
    long totalSem2  = todas.stream().filter(r -> r.getFechaHora().getMonthValue() >= 7).count();
    long cancelSem2 = todas.stream()
                           .filter(r -> r.getFechaHora().getMonthValue() >= 7)
                           .filter(r -> "cancelado".equalsIgnoreCase(r.getEstado()))
                           .count();
    long exitosSem2 = todas.stream()
                           .filter(r -> r.getFechaHora().getMonthValue() >= 7)
                           .filter(r -> "exitoso".equalsIgnoreCase(r.getEstado()))
                           .count();
    long pendSem2   = todas.stream()
                           .filter(r -> r.getFechaHora().getMonthValue() >= 7)
                           .filter(r -> "pendiente".equalsIgnoreCase(r.getEstado()))
                           .count();

    DefaultPieDataset ds2 = new DefaultPieDataset();
    ds2.setValue("Exitosos",   exitosSem2);
    ds2.setValue("Cancelados", cancelSem2);
    ds2.setValue("Pendientes", pendSem2);

    JFreeChart chart2 = ChartFactory.createPieChart("Resumen Semestral (Jul–Dic)", ds2, true, false, false);
    PiePlot plot2 = (PiePlot) chart2.getPlot();
    plot2.setSectionPaint("Exitosos", new Color(34,139,34));
    plot2.setSectionPaint("Cancelados", Color.RED);
    plot2.setSectionPaint("Pendientes", Color.GRAY);
    plot2.setBackgroundPaint(null);
    plot2.setOutlineVisible(false);

    BufferedImage img2 = chart2.createBufferedImage(400, 300);
    ByteArrayOutputStream baos2 = new ByteArrayOutputStream();
    ImageIO.write(img2, "png", baos2);
    Image itext2 = Image.getInstance(baos2.toByteArray());
    itext2.setAlignment(Element.ALIGN_CENTER);
    itext2.scaleToFit(400, 300);
    document.add(itext2);

    document.add(Chunk.NEWLINE);
    Paragraph pct2 = new Paragraph(
      String.format(
        "Exitosos: %d (%.1f%%)   Cancelados: %d (%.1f%%)   Pendientes: %d (%.1f%%)",
        exitosSem2, totalSem2>0 ? exitosSem2*100.0/totalSem2 : 0,
        cancelSem2, totalSem2>0 ? cancelSem2*100.0/totalSem2 : 0,
        pendSem2,   totalSem2>0 ? pendSem2*100.0/totalSem2 : 0
      ),
      small
    );
    pct2.setAlignment(Element.ALIGN_CENTER);
    document.add(pct2);


    // Año actual
    int year = LocalDate.now().getYear();
    long totalYear  = todas.stream().filter(r -> r.getFechaHora().getYear() == year).count();
    long cancelYear = todas.stream()
                           .filter(r -> r.getFechaHora().getYear() == year)
                           .filter(r -> "cancelado".equalsIgnoreCase(r.getEstado()))
                           .count();
    long exitosYear = todas.stream()
                           .filter(r -> r.getFechaHora().getYear() == year)
                           .filter(r -> "exitoso".equalsIgnoreCase(r.getEstado()))
                           .count();
    long pendYear   = todas.stream()
                           .filter(r -> r.getFechaHora().getYear() == year)
                           .filter(r -> "pendiente".equalsIgnoreCase(r.getEstado()))
                           .count();

    DefaultPieDataset dsYear = new DefaultPieDataset();
    dsYear.setValue("Exitosos",   exitosYear);
    dsYear.setValue("Cancelados", cancelYear);
    dsYear.setValue("Pendientes", pendYear);

    JFreeChart chartYear = ChartFactory.createPieChart("Resumen Año " + year, dsYear, true, false, false);
    PiePlot plotYear = (PiePlot) chartYear.getPlot();
    plotYear.setSectionPaint("Exitosos", new Color(34,139,34));
    plotYear.setSectionPaint("Cancelados", Color.RED);
    plotYear.setSectionPaint("Pendientes", Color.GRAY);
    plotYear.setBackgroundPaint(null);
    plotYear.setOutlineVisible(false);

    BufferedImage imgYear = chartYear.createBufferedImage(400, 300);
    ByteArrayOutputStream baosYear = new ByteArrayOutputStream();
    ImageIO.write(imgYear, "png", baosYear);
    Image itextYear = Image.getInstance(baosYear.toByteArray());
    itextYear.setAlignment(Element.ALIGN_CENTER);
    itextYear.scaleToFit(400, 300);
    document.add(Chunk.NEWLINE);
    document.add(itextYear);

    document.add(Chunk.NEWLINE);
    Paragraph pctYear = new Paragraph(
      String.format(
        "Exitosos: %d (%.1f%%)   Cancelados: %d (%.1f%%)   Pendientes: %d (%.1f%%)",
        exitosYear, totalYear>0 ? exitosYear*100.0/totalYear : 0,
        cancelYear, totalYear>0 ? cancelYear*100.0/totalYear : 0,
        pendYear,   totalYear>0 ? pendYear*100.0/totalYear : 0
      ),
      small
    );
    pctYear.setAlignment(Element.ALIGN_CENTER);
    document.add(pctYear);
    document.add(Chunk.NEWLINE);
    // Resumen General
    long totalAll  = todas.size();
    long cancelAll = todas.stream().filter(r -> "cancelado".equalsIgnoreCase(r.getEstado())).count();
    long exitosAll = todas.stream().filter(r -> "exitoso".equalsIgnoreCase(r.getEstado())).count();
    long pendAll   = todas.stream().filter(r -> "pendiente".equalsIgnoreCase(r.getEstado())).count();

    DefaultPieDataset dsAll = new DefaultPieDataset();
    dsAll.setValue("Exitosos",   exitosAll);
    dsAll.setValue("Cancelados", cancelAll);
    dsAll.setValue("Pendientes", pendAll);

    JFreeChart chartAll = ChartFactory.createPieChart("Resumen General (Todas Reservas)", dsAll, true, false, false);
    PiePlot plotAll = (PiePlot) chartAll.getPlot();
    plotAll.setSectionPaint("Exitosos", new Color(34,139,34));
    plotAll.setSectionPaint("Cancelados", Color.RED);
    plotAll.setSectionPaint("Pendientes", Color.GRAY);
    plotAll.setBackgroundPaint(null);
    plotAll.setOutlineVisible(false);

    BufferedImage imgAll = chartAll.createBufferedImage(400, 300);
    ByteArrayOutputStream baosAll = new ByteArrayOutputStream();
    ImageIO.write(imgAll, "png", baosAll);
    Image itextAll = Image.getInstance(baosAll.toByteArray());
    itextAll.setAlignment(Element.ALIGN_CENTER);
    itextAll.scaleToFit(400, 300);
    document.add(Chunk.NEWLINE);
    document.add(itextAll);

    document.add(Chunk.NEWLINE);
    Paragraph pctAll = new Paragraph(
      String.format(
        "Exitosos: %d (%.1f%%)   Cancelados: %d (%.1f%%)   Pendientes: %d (%.1f%%)",
        exitosAll, totalAll>0 ? exitosAll*100.0/totalAll : 0,
        cancelAll, totalAll>0 ? cancelAll*100.0/totalAll : 0,
        pendAll,   totalAll>0 ? pendAll*100.0/totalAll   : 0
      ),
      small
    );
    pctAll.setAlignment(Element.ALIGN_CENTER);
    document.add(pctAll);

    document.close();
    return baos;
}


@Override
public ByteArrayOutputStream crearReporteExcel(HttpServletResponse response) throws IOException {
    List<Reserva> todas = reservaRepo.findAll();
    XSSFWorkbook wb = new XSSFWorkbook();
    Sheet sheet = wb.createSheet("Todas Reservas");

    // Título
    Row r0 = sheet.createRow(0);
    Cell c0 = r0.createCell(0);
    c0.setCellValue("REPORTE DE RESERVAS (TODAS)");
    CellStyle titleStyle = wb.createCellStyle();
    XSSFFont fTitle = wb.createFont();
    fTitle.setBold(true);
    fTitle.setFontHeightInPoints((short)14);
    titleStyle.setFont(fTitle);
    c0.setCellStyle(titleStyle);
    sheet.addMergedRegion(new CellRangeAddress(0,0,0,7));

    // Encabezados
    Row header = sheet.createRow(2);
    String[] headers = {"N°","Cliente","Correo","Teléfono","Mesa","Personas","Estado","Comentarios"};
    CellStyle hStyle = wb.createCellStyle();
    XSSFFont fH = wb.createFont();
    fH.setBold(true);
    hStyle.setFont(fH);
    hStyle.setFillForegroundColor(IndexedColors.GREY_25_PERCENT.getIndex());
    hStyle.setFillPattern(FillPatternType.SOLID_FOREGROUND);
    for (int i = 0; i < headers.length; i++) {
        Cell ch = header.createCell(i);
        ch.setCellValue(headers[i]);
        ch.setCellStyle(hStyle);
    }

    // Datos
    int fila = 3, cnt = 1;
    for (Reserva r : todas) {
        Row row = sheet.createRow(fila++);
        row.createCell(0).setCellValue(cnt++);
        row.createCell(1).setCellValue(r.getNombre()+" "+r.getApellido());
        row.createCell(2).setCellValue(r.getCorreo());
        row.createCell(3).setCellValue(r.getTelefono());
        row.createCell(4).setCellValue(r.getMesa().getNroMesa());
        row.createCell(5).setCellValue(r.getCantidad());
        row.createCell(6).setCellValue(r.getEstado());
        String mot = r.getMotivoCancelacion() != null
                     ? r.getMotivoCancelacion()
                     : r.getComentario() != null ? r.getComentario() : "";
        row.createCell(7).setCellValue(mot);
    }

    // ==== INICIO BLOQUE: Resumen general de reservas ====
    // calcula totales
    int total = todas.size();
    long pend   = todas.stream().filter(r -> "pendiente".equalsIgnoreCase(r.getEstado())).count();
    long canc   = todas.stream().filter(r -> "cancelado".equalsIgnoreCase(r.getEstado())).count();
    long exito  = todas.stream().filter(r -> "exitoso".equalsIgnoreCase(r.getEstado())).count();

    // título del resumen
    Row resumenTitle = sheet.createRow(fila++);
    resumenTitle.createCell(0).setCellValue("--- Resumen de Reservas ---");

    // Total reservas
    Row totalRow = sheet.createRow(fila++);
    totalRow.createCell(0).setCellValue("Total reservas hechas:");
    totalRow.createCell(1).setCellValue(total);

    // Pendientes
    Row pendRow = sheet.createRow(fila++);
    pendRow.createCell(0).setCellValue("Pendientes:");
    pendRow.createCell(1).setCellValue(pend);

    // Canceladas
    Row cancRow = sheet.createRow(fila++);
    cancRow.createCell(0).setCellValue("Canceladas:");
    cancRow.createCell(1).setCellValue(canc);

    // Exitosas
    Row exiRow = sheet.createRow(fila++);
    exiRow.createCell(0).setCellValue("Exitosas:");
    exiRow.createCell(1).setCellValue(exito);
    // ==== FIN BLOQUE: Resumen general de reservas ====

    // Resumen porcentajes mensuales (opcional)
    LocalDate ahora = LocalDate.now();
    int mes = ahora.getMonthValue();
    long totalMes  = todas.stream().filter(r->r.getFechaHora().getMonthValue()==mes).count();
    long cancelMes = todas.stream()
                          .filter(r->r.getFechaHora().getMonthValue()==mes)
                          .filter(r->"cancelado".equalsIgnoreCase(r.getEstado()))
                          .count();
    long atendMes  = todas.stream()
                          .filter(r->r.getFechaHora().getMonthValue()==mes)
                          .filter(r->"atendido".equalsIgnoreCase(r.getEstado()))
                          .count();
    double pctCancel = totalMes>0 ? cancelMes*100.0/totalMes : 0;
    double pctAtend  = totalMes>0 ? atendMes*100.0/totalMes  : 0;

    Row pctRow = sheet.createRow(fila++);
    pctRow.createCell(0).setCellValue(
      String.format("Mes %d — Total: %d  Canceladas: %d (%.1f%%)  Atendidas: %d (%.1f%%)",
                    mes, totalMes, cancelMes, pctCancel, atendMes, pctAtend)
    );

    // Auto-ajustar columnas
    for (int i = 0; i < headers.length; i++) {
        sheet.autoSizeColumn(i);
    }
    sheet.autoSizeColumn(0);
    sheet.autoSizeColumn(1);

    ByteArrayOutputStream out = new ByteArrayOutputStream();
    wb.write(out);
    wb.close();
    return out;
}

    @Override
    public ResponseEntity<String> cancelarReserva(int idReserva) {
        Reserva r = reservaRepo.findById(idReserva).orElse(null);
        if (r == null) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND)
                                 .body("Reserva no encontrada");
        }
        r.setEstado("cancelado");
        reservaRepo.save(r);
        return ResponseEntity.ok("Reserva cancelada correctamente");
    }

    @Override
    public ResponseEntity<String> cancelar(int idReserva) {
        Reserva r = reservaRepo.findById(idReserva).orElse(null);
        if (r == null) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND)
                                 .body("Reserva no encontrada");
        }
        r.setEstado("cancelado");
        reservaRepo.save(r);
        return ResponseEntity.ok("Reserva cancelada correctamente");
    }

    @Override
    public ResponseEntity<String> cancelar(int idReserva, String motivo) {
        Reserva r = reservaRepo.findById(idReserva).orElse(null);
        if (r == null) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND)
                                 .body("Reserva no encontrada");
        }
        r.setEstado("cancelado");
        r.setMotivoCancelacion(motivo);
        reservaRepo.save(r);
        return ResponseEntity.ok("Reserva cancelada con motivo: " + motivo);
    }

    @Override
    public ResponseEntity<String> comentar(int idReserva, String comentario) {
        Reserva r = reservaRepo.findById(idReserva).orElse(null);
        if (r == null) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND)
                                 .body("Reserva no encontrada");
        }
        r.setComentario(comentario);
        reservaRepo.save(r);
        return ResponseEntity.ok("Comentario guardado");
    }
}
