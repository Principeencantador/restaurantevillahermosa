package com.example.demo.security;

import com.example.demo.security.jwt.jwtFilter;   // ¡Asegúrate de este import!
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.dao.DaoAuthenticationProvider;
import org.springframework.security.config.annotation.authentication.configuration.AuthenticationConfiguration;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;
import org.springframework.web.cors.CorsConfiguration;
import org.springframework.web.cors.CorsConfigurationSource;
import org.springframework.web.cors.UrlBasedCorsConfigurationSource;

import java.util.Arrays;
import java.util.List;

@Configuration
@EnableWebSecurity
public class SecurityConfig {

    @Autowired
    private UsuarioDetailsService empleadoDetailsService;

    @Autowired
    private jwtFilter jwtFilter;

    @Bean
    public PasswordEncoder passwordEncoder() {
        return new BCryptPasswordEncoder();
    }

    @Bean
    public DaoAuthenticationProvider authenticationProvider() {
        DaoAuthenticationProvider authProv = new DaoAuthenticationProvider();
        authProv.setUserDetailsService(empleadoDetailsService);
        authProv.setPasswordEncoder(passwordEncoder());
        return authProv;
    }

    @Bean
    public AuthenticationManager authenticationManager(
            AuthenticationConfiguration authConfig) throws Exception {
        return authConfig.getAuthenticationManager();
    }

    @Bean
    public CorsConfigurationSource corsConfigurationSource() {
        CorsConfiguration config = new CorsConfiguration();
        config.setAllowedOrigins(List.of("http://localhost:3000"));
        config.setAllowedMethods(Arrays.asList("GET", "POST", "PUT", "DELETE", "OPTIONS"));
        config.setAllowedHeaders(Arrays.asList("Authorization", "Content-Type", "Accept"));
        config.setExposedHeaders(List.of("Authorization"));
        config.setAllowCredentials(true);

        UrlBasedCorsConfigurationSource source = new UrlBasedCorsConfigurationSource();
        source.registerCorsConfiguration("/**", config);
        return source;
    }

    @Bean
    public SecurityFilterChain securityFilterChain(HttpSecurity http) throws Exception {
        http
          .cors(cors -> cors.configurationSource(corsConfigurationSource()))
          .csrf().disable()
          .sessionManagement(sess ->
              sess.sessionCreationPolicy(SessionCreationPolicy.STATELESS)
          )
          .authenticationProvider(authenticationProvider())
          .authorizeHttpRequests(auth -> auth
              // ENDPOINTS PÚBLICOS (login, registro, listar platos e imágenes)
              .requestMatchers(
                  "/empleado/login",
                  "/empleado/registrar",
                        "/reserva/crearreporte",
      "/reserva/excelreservas",
                  "/plato/listar", "/reserva/cancelar",  
                  "/reserva/comentar", "/agregar-platos",
                  "/eliminar-plato", "/pedido/listar",
                  "/create-checkout-session", "/actualizarEstado",
                  "/webhook", "/{id}/rembolso",
                  "/{id}/factura/pdf", "/{id}/factura/send",
                  "/listarPendientes", "/listarAtendidos",
                  "/cancelar-linea", "/listar",
                  "/pedido/listarPendientes", "/pedido/listarAtendidos",
                  "/pedido/cancelar-linea", "/pedido/guardar",
                  "/pedido/agregar-platos", "/pedido/create-checkout-session",
                  "/pedido/actualizarEstado", "/pedido/webhook",
                  "/pedido/{id}/rembolso", "/pedido/{id}/factura/pdf",
                  "/pedido/{id}/factura/send", "/pedido/comentar",
                  "/pagar/{id}", "/empleado/verificar",
                "/reserva/diaria", "/reserva/atendidas",
                "/reserva/ocupadas",

                  "/uploads/**"
                  
                  
              ).permitAll()
              // Si quieres seguir permitiendo estos:
              
              .requestMatchers(
                  "/reserva/disponibilidad",
                  "/pedido/listarAtendidos",
                  "/pedido/listarPendientes",
                  "/success", "/sucess"
              ).permitAll()
              // RUTAS ADMIN
              .requestMatchers("/admin/**").hasRole("ADMIN")
              // CUALQUIER OTRA REQUIERE AUTENTICACIÓN
              .anyRequest().authenticated()
          )
          // Antes del filtro de usuario/pass, inyecta nuestro filtro JWT
          .addFilterBefore(jwtFilter, UsernamePasswordAuthenticationFilter.class);

        return http.build();
    }
}
