package com.example.demo.security.jwt;

import java.io.IOException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Component;
import org.springframework.web.filter.OncePerRequestFilter;

import com.example.demo.security.UsuarioDetailsService;

import io.jsonwebtoken.ExpiredJwtException;
import io.jsonwebtoken.JwtException;
import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@Component
public class jwtFilter extends OncePerRequestFilter {

  @Autowired
  private jwtUtil jwtUtil;

  @Autowired
  private UsuarioDetailsService userDetailsService;

  // Rutas que queremos IGNORAR totalmente (ni validamos JWT)
  private static final List<String> PUBLIC_PATHS = List.of(
    "/empleado/login",
    "/empleado/registrar",
    "/plato/listar",
    "/pedido/listar"      // <-- aquí incluimos la ruta a la que quieres acceder sin token válido
  );

  @Override
  protected void doFilterInternal(HttpServletRequest req,
                                  HttpServletResponse res,
                                  FilterChain chain)
      throws ServletException, IOException {

    String uri = req.getRequestURI();
    log.debug("jwtFilter, request URI = {}", uri);

    // 1) Si la URI está en PUBLIC_PATHS o es estática de uploads, no validamos
    if (PUBLIC_PATHS.contains(uri) || uri.startsWith("/uploads/")) {
      chain.doFilter(req, res);
      return;
    }

    // 2) Para el resto, extraemos el Bearer token
    String authHeader = req.getHeader("Authorization");
    if (authHeader != null && authHeader.startsWith("Bearer ")) {
      String token = authHeader.substring(7);
      try {
        String username = jwtUtil.extractUsername(token);
        if (SecurityContextHolder.getContext().getAuthentication() == null) {
          UserDetails userDetails = userDetailsService.loadUserByUsername(username);
          if (jwtUtil.validateToken(token, userDetails)) {
            UsernamePasswordAuthenticationToken auth =
              new UsernamePasswordAuthenticationToken(
                userDetails, null, userDetails.getAuthorities());
            SecurityContextHolder.getContext().setAuthentication(auth);
          }
        }
      } catch (ExpiredJwtException ex) {
        log.warn("Token expirado al acceder {}: {}", uri, ex.getMessage());
        // Respondemos aquí en caliente para que no caiga en 403 sin cuerpo
        res.setStatus(HttpServletResponse.SC_UNAUTHORIZED);
        res.setContentType("application/json");
        res.getWriter().write("{\"error\":\"Token expirado, inicia sesión de nuevo.\"}");
        return;
      } catch (JwtException ex) {
        log.error("Token inválido al acceder {}: {}", uri, ex.getMessage());
        res.sendError(HttpServletResponse.SC_UNAUTHORIZED, "Token JWT inválido");
        return;
      }
    }

    // 3) Continuamos el chain (Spring Security autorizará según tu SecurityConfig)
    chain.doFilter(req, res);
  }
}
