package com.example.demo.controller;

import java.time.LocalDateTime;
import java.util.Arrays;
import java.util.List;
import java.util.Map;

import com.example.demo.dao.pedidorepository;
import com.example.demo.entity.Pedido;
import com.example.demo.service.FacturaService;
import com.example.demo.service.pagoimpl;
import com.example.demo.service.pedidoimpl;
import com.itextpdf.text.DocumentException;
import com.stripe.Stripe;
import com.stripe.exception.SignatureVerificationException;
import com.stripe.exception.StripeException;
import com.stripe.model.Event;
import com.stripe.model.PaymentIntent;
import com.stripe.net.Webhook;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.http.HttpHeaders;         // <-- import corregido
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.web.bind.annotation.*;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@RestController
@RequestMapping("/pedido")
public class pedidocontroller {

    @Value("${stripe.key.secret}")
    private String secretkey;

    @Autowired
    private JavaMailSender mailSender;

    @Autowired
    private pedidorepository pedidodao;

    @Autowired
    private pedidoimpl pedidoimpl;

    @Autowired
    private pagoimpl pagoimpl;

    @Autowired
    private FacturaService facturaService;

    // ------------------ ENDPOINTS DE PEDIDO ------------------

    @PostMapping("/guardar")
    public ResponseEntity<String> guardar(@RequestBody Map<String, Object> params) {
        LocalDateTime datetime = LocalDateTime.now();
        return pedidoimpl.guardarPedido(params, datetime);
    }

    @PostMapping("/agregar-platos")
    public ResponseEntity<String> agregarPlatos(@RequestBody Map<String, Object> params) {
        return pedidoimpl.agregarplatos(params);
    }

    @PostMapping("/eliminar-plato")
    public ResponseEntity<String> eliminarPlato(
            @RequestParam("id_plato") int idPlato,
            @RequestParam("id_pedidoplato") int idPedidoPlato) {
        return pedidoimpl.eliminarplatopedido(idPlato, idPedidoPlato);
    }

    @GetMapping("/listar")
    public ResponseEntity<?> listarPedidos(@RequestHeader("Authorization") String authHeader) {
        try {
            return ResponseEntity.ok(pedidodao.findAll());
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                .body("Error al listar pedidos: " + e.getMessage());
        }
    }

    @PostMapping("/create-checkout-session")
    public ResponseEntity<Map<String, String>> checkout(@RequestBody Map<String, Object> mapeo) {
        return pagoimpl.sesionpay(mapeo);
    }

    @PostMapping("/actualizarEstado")
    public ResponseEntity<String> actualizarEstado(@RequestBody Map<String, String> request) {
        return pedidoimpl.actualizarEstado(request);
    }

    @PostMapping("/webhook")
    public ResponseEntity<String> handleStripeWebhook(
            @RequestBody String payload,
            @RequestHeader("Stripe-Signature") String sigHeader) {

        Stripe.apiKey = secretkey;
        String endpointSecret = "whsec_…";

        try {
            Event event = Webhook.constructEvent(payload, sigHeader, endpointSecret);

            if ("payment_intent.succeeded".equals(event.getType())) {
                PaymentIntent intent = (PaymentIntent) event
                    .getDataObjectDeserializer()
                    .getObject()
                    .orElse(null);

                if (intent != null) {
                    String pedidoIdStr = intent.getMetadata().get("pedido_id");
                    Pedido pedido = pedidodao.findById(Integer.parseInt(pedidoIdStr))
                                             .orElse(null);

                    if (pedido != null) {
                        pedido.setEstado("PAGADO");
                        pedido.setId_pago(intent.getId());
                        pedidodao.save(pedido);

                        SimpleMailMessage msg = new SimpleMailMessage();
                        msg.setTo(pedido.getId_usuario().getEmail());
                        msg.setSubject("Pedido pagado");
                        msg.setText("El pedido con id: " + pedido.getId_pedido()
                                    + " fue pagado exitosamente");
                        msg.setFrom("marioelpro08@gmail.com");
                        mailSender.send(msg);

                        facturaService.enviarFacturaPorCorreo((long) pedido.getId_pedido());
                    }
                }
            }

        } catch (SignatureVerificationException e) {
            log.error("Webhook signature verification failed:", e);
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).build();
        } catch (Exception e) {
            log.error("Error procesando webhook de Stripe:", e);
        }

        return ResponseEntity.ok().build();
    }

    @PostMapping("/{id}/rembolso")
    public ResponseEntity<String> rembolso(@PathVariable("id") Long id) throws StripeException {
        Map<String, String> params = Map.of("id_pedido", id.toString());
        return pedidoimpl.rembolso(params, secretkey);
    }

    @GetMapping("/{id}/factura/pdf")
    public ResponseEntity<ByteArrayResource> descargarFactura(@PathVariable Long id) {
        try {
            byte[] pdf = facturaService.generarFacturaPdf(id);
            return ResponseEntity.ok()
                    .header(HttpHeaders.CONTENT_DISPOSITION,
                            "attachment; filename=\"boleta_" + id + ".pdf\"")
                    .contentType(MediaType.APPLICATION_PDF)
                    .contentLength(pdf.length)
                    .body(new ByteArrayResource(pdf));
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).build();
        }
    }

    @PostMapping("/{id}/factura/send")
    public ResponseEntity<String> enviarFactura(@PathVariable Long id) {
        try {
            facturaService.enviarFacturaPorCorreo(id);
            return ResponseEntity.ok("Factura enviada correctamente");
        } catch (Exception e) {
            log.error("Error al enviar factura pedido {}: {}", id, e.getMessage(), e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body("Error al enviar factura: " + e.getMessage());
        }
    }

    @GetMapping("/listarPendientes")
    public ResponseEntity<?> listarPedidosPendientes(@RequestHeader("Authorization") String authHeader) {
        try {
            List<Pedido> pedidosPendientes = pedidodao.findByEstado("ESPERA");
            return ResponseEntity.ok(pedidosPendientes);
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                .body("Error al listar pedidos pendientes: " + e.getMessage());
        }
    }

 @GetMapping("/listarAtendidos")
public ResponseEntity<?> listarPedidosAtendidos(@RequestHeader("Authorization") String authHeader) {
    try {
        // incluye PAGADO junto a atendido y terminado
        List<String> estados = Arrays.asList("atendido", "terminado", "PAGADO");
        List<Pedido> pedidosAtendidos = pedidodao.findByEstadoIn(estados);
        return ResponseEntity.ok(pedidosAtendidos);
    } catch (Exception e) {
        return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
            .body("Error al listar pedidos atendidos: " + e.getMessage());
    }
}
    // Nuevo endpoint para marcar como pagado desde la página "success"
    @PostMapping("/pagar/{id}")
    public ResponseEntity<String> pagarPedido(
        @PathVariable("id") Integer idPedido
    ) {
        Pedido pedido = pedidodao.findById(idPedido).orElse(null);
        if (pedido == null) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND)
                                 .body("Pedido no encontrado");
        }
        if ("PAGADO".equalsIgnoreCase(pedido.getEstado())) {
            return ResponseEntity.ok("Pedido ya estaba pagado");
        }
        pedido.setEstado("PAGADO");
        pedidodao.save(pedido);
        return ResponseEntity.ok("Pedido marcado como pagado");
    }
}
