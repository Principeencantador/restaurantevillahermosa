package dao;

public class platorepository {

}
